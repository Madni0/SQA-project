# Bug Report: BR002

## General Information
- **Bug ID**: BR002
- **Title**: Shopping Cart Quantity Not Updating When Clicking Increase Button
- **Date Reported**: January 18, 2025
- **Reporter**: QA Team
- **Status**: Open
- **Severity**: High
- **Priority**: P2 (High)
- **Component**: Shopping Cart Module
- **Assigned To**: Frontend Development Team

## Description
When a user clicks the increase (+) button to increment the quantity of an item in the shopping cart, the quantity value does not increase on the UI. However, the backend may have updated correctly, causing a discrepancy between the displayed quantity and actual quantity.

## Steps to Reproduce
1. Log in with valid credentials (test@example.com / password123)
2. Navigate to a restaurant menu
3. Add any menu item to cart (e.g., Biryani for Rs. 500)
4. Click on "Cart" to view shopping cart
5. Click the "+" (increase) button next to the item
6. Observe the quantity value

## Expected Result
- Quantity displayed changes from 1 to 2
- Unit price remains the same
- Total price updates to 1000 (500 × 2)
- Change is reflected immediately without page refresh
- Backend cart is updated with new quantity

## Actual Result
- Quantity remains displayed as 1
- No visual update occurs
- Total price remains unchanged
- Page refresh shows correct quantity (indicating backend updated)
- UI is not synchronized with backend state

## Environment Details
- **Browser**: Google Chrome v120.0
- **OS**: Windows 11
- **Application URL**: http://localhost:3000
- **Browser Console Error**: 
  ```
  TypeError: Cannot read property 'quantity' of undefined at setCartQuantity
  ```

## Root Cause Analysis
- Potential issue with React state management or hooks
- Event handler may not be firing correctly
- State might not be re-rendering after quantity change

## Workaround
Refresh the page after modifying cart quantity to see updated values.

## Severity Justification
- Impacts core feature (shopping cart management)
- Causes user confusion about cart contents
- May lead to incorrect orders if quantity discrepancy exists

## Screenshots
[Screenshot 1: Cart page with item quantity = 1]
[Screenshot 2: After clicking +, quantity still shows 1]
[Screenshot 3: After page refresh, quantity correctly shows 2]

## Related Test Cases
- TC010: Increase Item Quantity in Cart
- TC011: Decrease Item Quantity in Cart

## Recommendations
1. Review cart state management logic
2. Check event handler binding for increase/decrease buttons
3. Ensure component re-renders after state change
4. Add console logging to trace quantity updates
5. Implement optimistic UI updates with backend confirmation

---
**Bug Report Version**: 1.0  
**Last Updated**: January 18, 2025
