# Bug Report: BR006

## General Information
- **Bug ID**: BR006
- **Title**: Order Status Not Updating in Real-Time for Customer
- **Date Reported**: January 18, 2025
- **Reporter**: QA Team
- **Status**: Open
- **Severity**: High
- **Priority**: P2 (High)
- **Component**: Order Tracking Module
- **Assigned To**: Backend/Full-stack Development Team

## Description
When an admin updates the order status in the admin dashboard (e.g., from \"Pending\" to \"Preparing\"), the customer does not see the updated status in their order tracking page until they manually refresh the page. Real-time updates are not working.

## Steps to Reproduce
1. Place an order as a customer (test@example.com)
2. Note the order ID: ORD-12345
3. Keep the customer's order tracking page open in one browser/tab
4. In another browser window, log in as admin (admin@example.com)
5. Navigate to Admin > Orders
6. Find the order (ORD-12345)
7. Click on the order and change status from \"Pending\" to \"Preparing\"
8. Click \"Update\" button
9. Return to customer's browser tab and observe the status

## Expected Result
- Customer's page updates automatically within 2-3 seconds
- Status changes from \"Pending\" to \"Preparing\" without page refresh
- Timestamp updates to reflect the status change
- Notification appears alerting customer of status update
- Real-time sync between admin and customer views

## Actual Result
- Customer's page shows \"Pending\" status
- No automatic update occurs
- Status remains unchanged until customer manually refreshes page
- After refresh, correct status \"Preparing\" is displayed
- No notification received by customer

## Technical Details
- **API Endpoint Updated**: PATCH /api/orders/:orderId/status
- **Expected WebSocket/Real-time Service**: Not implemented
- **Current Implementation**: Poll-based (customers must refresh)
- **Data Fetch Interval**: Only on page load

## Environment Details
- **Browser**: Chrome v120.0
- **Admin Browser**: Chrome v120.0 (separate instance)
- **Application URL**: http://localhost:3000
- **Database**: MongoDB (Local)

## Root Cause
Real-time communication mechanism not implemented. System uses traditional request-response model without WebSockets or Server-Sent Events (SSE).

## Business Impact
- Poor customer experience
- Customers unaware of order progress
- Increased support inquiries about order status
- Customer frustration and trust issues

## Severity Justification
- Impacts core feature (order tracking)
- Affects user experience for all customers
- Real-time updates are expected in modern apps
- High-priority feature per requirements

## Screenshots
[Screenshot 1: Admin dashboard showing order status changed to \"Preparing\"]
[Screenshot 2: Customer page still showing \"Pending\" status]
[Screenshot 3: After manual refresh, customer sees correct \"Preparing\" status]

## Related Test Cases
- TC018: Track Order Status
- TC026: Admin Update Order Status

## Recommendations
1. Implement WebSocket communication (Socket.IO recommended)
2. Add real-time listeners to order tracking page
3. Emit status update events from backend when admin updates status
4. Update customer UI reactively when socket event received
5. Add notification system to alert customers of status changes
6. Implement automatic polling as fallback for WebSocket failures
7. Add visual indicator when page is in sync/out of sync

## Technical Approach
```javascript
// Client-side (React)
useEffect(() => {
  const socket = io('http://localhost:3000');
  socket.on('order-status-updated', (order) => {
    if (order.id === orderId) {
      setOrderStatus(order.status);
      showNotification(`Order status: ${order.status}`);
    }
  });
  return () => socket.disconnect();
}, []);

// Server-side (Node.js)
router.patch('/orders/:id/status', (req, res) => {
  // Update status in DB
  // Emit to all connected clients
  io.emit('order-status-updated', updatedOrder);
});
```

---
**Bug Report Version**: 1.0  
**Last Updated**: January 18, 2025
