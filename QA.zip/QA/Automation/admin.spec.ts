import { test, expect } from '@playwright/test';

test.describe('Admin Dashboard Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000');
    
    // Login as admin
    await page.click('text=Login');
    await page.fill('input[name="email"]', 'admin@example.com');
    await page.fill('input[name="password"]', 'adminpass123');
    await page.click('button[type="submit"]');
    
    // Wait for admin dashboard to load
    await page.waitForURL(/.*admin|.*dashboard/);
  });

  test('TC021: Admin Login with Valid Credentials', async ({ page }) => {
    // Already done in beforeEach, verify we're on admin dashboard
    const adminTitle = page.locator('text=Admin Dashboard, text=Management, text=Admin Panel');
    await expect(adminTitle).toBeVisible({ timeout: 3000 });
  });

  test('TC022: Admin Add Menu Item', async ({ page }) => {
    // Navigate to menu management
    await page.click('text=Menu, text=Menu Management, text=Items');
    
    // Wait for menu page to load
    await page.waitForTimeout(1000);
    
    // Click add new item button
    const addButton = page.locator('button:has-text("Add Item"), button:has-text("Add Menu Item"), button:has-text("New Item")');
    await addButton.click();
    
    // Wait for form to appear
    await page.waitForTimeout(1000);
    
    // Fill item details
    const timestamp = Date.now();
    await page.fill('input[name="name"]', `Chicken Karahi ${timestamp}`);
    await page.fill('input[name="description"]', 'Spicy chicken curry with tomatoes and peppers');
    await page.fill('input[name="price"]', '800');
    
    // Select category if available
    const categorySelect = page.locator('select[name="category"]');
    if (await categorySelect.count() > 0) {
      await categorySelect.click();
      await page.locator('text=Curry, text=Curries, text=Main Course').first().click();
    }
    
    // Handle image upload if required
    const imageInput = page.locator('input[type="file"]');
    // Note: In real scenario, upload actual image file
    
    // Save the item
    const saveButton = page.locator('button:has-text("Save"), button:has-text("Add Item"), button:has-text("Create")');
    await saveButton.click();
    
    // Wait and verify success message
    await page.waitForTimeout(1500);
    
    const successMessage = page.locator('text=/added|created|successfully/i');
    await expect(successMessage).toBeVisible({ timeout: 3000 });
  });

  test('TC023: Admin Edit Menu Item', async ({ page }) => {
    // Navigate to menu management
    await page.click('text=Menu, text=Menu Management, text=Items');
    
    await page.waitForTimeout(1000);
    
    // Find and click edit button for first item
    const editButton = page.locator('button:has-text("Edit"), button[aria-label*="edit"]').first();
    await editButton.click();
    
    // Wait for edit form
    await page.waitForTimeout(1000);
    
    // Update price
    const priceInput = page.locator('input[name="price"]');
    await priceInput.clear();
    await priceInput.fill('900');
    
    // Update description
    const descInput = page.locator('textarea[name="description"]');
    if (await descInput.count() > 0) {
      await descInput.clear();
      await descInput.fill('Updated description - Delicious spicy curry');
    }
    
    // Save changes
    const saveButton = page.locator('button:has-text("Save"), button:has-text("Update")');
    await saveButton.click();
    
    // Wait for confirmation
    await page.waitForTimeout(1500);
    
    // Verify success
    const successMessage = page.locator('text=/updated|saved|successfully/i');
    await expect(successMessage).toBeVisible({ timeout: 3000 });
  });

  test('TC024: Admin Delete Menu Item', async ({ page }) => {
    // Navigate to menu management
    await page.click('text=Menu, text=Menu Management, text=Items');
    
    await page.waitForTimeout(1000);
    
    // Get initial item count
    const items = page.locator('[class*="item"], [class*="row"]');
    const initialCount = await items.count();
    
    // Click delete button on first item
    const deleteButton = page.locator('button:has-text("Delete"), button[aria-label*="delete"]').first();
    await deleteButton.click();
    
    // Confirm deletion if prompted
    const confirmButton = page.locator('button:has-text("Confirm"), button:has-text("Yes"), button:has-text("Delete")');
    if (await confirmButton.count() > 0) {
      await confirmButton.click();
    }
    
    // Wait and verify
    await page.waitForTimeout(1500);
    
    const successMessage = page.locator('text=/deleted|removed/i');
    await expect(successMessage).toBeVisible({ timeout: 3000 });
  });

  test('TC025: Admin View Orders Dashboard', async ({ page }) => {
    // Navigate to orders management
    await page.click('text=Orders, text=Order Management, text=All Orders');
    
    // Wait for orders to load
    await page.waitForTimeout(2000);
    
    // Verify orders are displayed
    const ordersTable = page.locator('[class*="orders"], [class*="table"]');
    await expect(ordersTable).toBeVisible({ timeout: 3000 });
    
    // Check for order columns
    const orderIdHeader = page.locator('th:has-text("Order ID"), th:has-text("Order #"), th:has-text("ID")');
    const customerHeader = page.locator('th:has-text("Customer"), th:has-text("User")');
    const statusHeader = page.locator('th:has-text("Status")');
    
    await expect(orderIdHeader).toBeVisible({ timeout: 2000 });
  });

  test('TC026: Admin Update Order Status', async ({ page }) => {
    // Navigate to orders
    await page.click('text=Orders, text=Order Management, text=All Orders');
    
    await page.waitForTimeout(2000);
    
    // Click on first order to open details
    const orderRow = page.locator('[class*="order-row"], [class*="row"]').first();
    await orderRow.click();
    
    // Wait for order details
    await page.waitForTimeout(1000);
    
    // Find status dropdown or selector
    const statusSelect = page.locator('select[name="status"]');
    if (await statusSelect.count() > 0) {
      await statusSelect.click();
      await page.locator('option:has-text("Preparing"), text=Preparing').click();
    } else {
      // Try button approach
      const statusButton = page.locator('button:has-text("Pending"), button:has-text("Status")').first();
      if (await statusButton.count() > 0) {
        await statusButton.click();
        await page.locator('text=Preparing').click();
      }
    }
    
    // Save or confirm
    const saveButton = page.locator('button:has-text("Update"), button:has-text("Save")');
    if (await saveButton.count() > 0) {
      await saveButton.click();
    }
    
    // Wait and verify
    await page.waitForTimeout(1500);
    
    const successMessage = page.locator('text=/updated|saved|success/i');
    await expect(successMessage).toBeVisible({ timeout: 3000 });
  });

  test('TC027: Admin View Registered Users', async ({ page }) => {
    // Navigate to user management
    await page.click('text=Users, text=User Management, text=Customers');
    
    // Wait for users to load
    await page.waitForTimeout(2000);
    
    // Verify users list is displayed
    const usersList = page.locator('[class*="users"], [class*="table"]');
    await expect(usersList).toBeVisible({ timeout: 3000 });
    
    // Check for user columns
    const nameHeader = page.locator('th:has-text("Name")');
    const emailHeader = page.locator('th:has-text("Email")');
    const phoneHeader = page.locator('th:has-text("Phone")');
    
    await expect(nameHeader).toBeVisible({ timeout: 2000 });
    await expect(emailHeader).toBeVisible({ timeout: 2000 });
  });
});
