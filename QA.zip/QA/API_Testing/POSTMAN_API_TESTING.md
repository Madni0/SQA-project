# LAYYAH EATS - COMPLETE POSTMAN API TESTING GUIDE

Based on actual Next.js API implementation  
**With Menu/Restaurant Setup + Complete Order Workflow**

---

## FULL WORKFLOW: CREATE MENU ITEMS + PLACE ORDERS

### Environment Variables (Create in Postman)
```
base_url: http://localhost:3000
admin_token: (auto-populated after admin login)
user_token: (auto-populated after user login)
restaurant_id: (auto-populated from restaurant creation)
menu_item_id: (auto-populated from menu creation)
user_id: (auto-populated after user registration)
order_id: (auto-populated from order creation)
```

---

## PHASE 1: ADMIN SETUP (Add Restaurants & Menu Items)

### STEP 1: REGISTER ADMIN USER
**Endpoint:** `POST {{base_url}}/api/auth/register`  
**Status Code:** 201

#### Request Body
```json
{
  "name": "Admin User",
  "email": "admin@layyaheats.com",
  "phone": "03001234567",
  "password": "AdminPass123"
}
```

#### Tests Tab
```javascript
pm.test("Admin user registered", function () {
    pm.expect(pm.response.code).to.equal(201);
});
```

---

### STEP 2: LOGIN ADMIN USER
**Endpoint:** `POST {{base_url}}/api/auth/login`  
**Status Code:** 200

#### Request Body
```json
{
  "email": "admin@layyaheats.com",
  "password": "AdminPass123"
}
```

#### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

var jsonData = pm.response.json();
pm.environment.set('admin_id', jsonData.user.id);
```

---

### STEP 3: CREATE RESTAURANT (Admin)
**Endpoint:** `POST {{base_url}}/api/admin/restaurants`  
**Status Code:** 201  
**Auth:** Cookie (Admin session)

#### Request Headers
```
Content-Type: application/json
```

#### Request Body
```json
{
  "id": "rest_001",
  "name": "Food Palace",
  "description": "Premium Pakistani Restaurant",
  "address": "123 Main Street, Layyah",
  "phone": "03001234567",
  "rating": 4.5,
  "image": "https://via.placeholder.com/300",
  "cuisines": ["Pakistani", "Biryani"]
}
```

#### Tests Tab
```javascript
pm.test("Restaurant created", function () {
    pm.expect(pm.response.code).to.equal(200).or.to.equal(201);
});

var jsonData = pm.response.json();
pm.environment.set('restaurant_id', jsonData.restaurant._id || jsonData.restaurant.id);
```

---

### STEP 4: ADD MENU ITEM 1 (Admin)
**Endpoint:** `POST {{base_url}}/api/admin/menu`  
**Status Code:** 201  
**Auth:** Cookie (Admin session)

#### Request Body
```json
{
  "id": "menu_001",
  "name": "Chicken Karahi",
  "description": "Spicy chicken curry with tomatoes and peppers",
  "price": 800,
  "category": "Curries",
  "restaurantId": "rest_001",
  "image": "https://via.placeholder.com/300",
  "available": true
}
```

#### Tests Tab
```javascript
pm.test("Menu item created", function () {
    pm.expect(pm.response.code).to.equal(200).or.to.equal(201);
});

var jsonData = pm.response.json();
if (jsonData.menuItem && jsonData.menuItem._id) {
    pm.environment.set('menu_item_id', jsonData.menuItem._id);
}
```

---

### STEP 5: ADD MENU ITEM 2 (Admin)
**Endpoint:** `POST {{base_url}}/api/admin/menu`  
**Status Code:** 201  
**Auth:** Cookie (Admin session)

#### Request Body
```json
{
  "id": "menu_002",
  "name": "Biryani Special",
  "description": "Fragrant rice with tender meat",
  "price": 600,
  "category": "Rice Dishes",
  "restaurantId": "rest_001",
  "image": "https://via.placeholder.com/300",
  "available": true
}
```

#### Tests Tab
```javascript
pm.test("Menu item 2 created", function () {
    pm.expect(pm.response.code).to.equal(200).or.to.equal(201);
});
```

---

### STEP 6: ADD MENU ITEM 3 (Admin)
**Endpoint:** `POST {{base_url}}/api/admin/menu`  
**Status Code:** 201  
**Auth:** Cookie (Admin session)

#### Request Body
```json
{
  "id": "menu_003",
  "name": "Nihari",
  "description": "Traditional slow-cooked meat stew",
  "price": 500,
  "category": "Curries",
  "restaurantId": "rest_001",
  "image": "https://via.placeholder.com/300",
  "available": true
}
```

---

## PHASE 2: USER WORKFLOW (Register → Order)

### API #1: USER REGISTRATION
**Endpoint:** `POST {{base_url}}/api/auth/register`  
**Status Code:** 201  
**Auth:** None

### Request Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "name": "Test User",
  "email": "testuser@example.com",
  "phone": "03001234567",
  "password": "TestPass123"
}
```

### Expected Response (201)
```json
{
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "Test User",
    "email": "testuser@example.com"
  }
}
```

### Tests Tab
```javascript
pm.test("Status code is 201", function () {
    pm.expect(pm.response.code).to.equal(201);
});

pm.test("Response has user id", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.user).to.have.property('id');
    pm.expect(jsonData.user.email).to.equal('testuser@example.com');
});

// Extract token from cookie for next requests
var cookies = pm.cookies.jar.cookies;
pm.environment.set('auth_token', cookies.length > 0 ? cookies[0].value : '');
```

---

## API #2: USER LOGIN
**Endpoint:** `POST {{base_url}}/api/auth/login`  
**Status Code:** 200  
**Auth:** None

### Request Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "email": "testuser@example.com",
  "password": "TestPass123"
}
```

### Expected Response (200)
```json
{
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "email": "testuser@example.com",
    "name": "Test User",
    "isAdmin": false
  }
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has user object", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('user');
    pm.expect(jsonData.user).to.have.property('id');
    pm.expect(jsonData.user).to.have.property('email');
});

pm.test("User email matches request", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.user.email).to.equal('testuser@example.com');
});
```

---

## API #3: GET ALL MENU ITEMS
**Endpoint:** `GET {{base_url}}/api/menu`  
**Status Code:** 200  
**Auth:** None  
**Query Params:** Optional - `restaurantId=<id>`

### Request Headers
```
Content-Type: application/json
```

### Request Body
```
None
```

### Expected Response (200)
```json
{
  "menu": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "name": "Chicken Karahi",
      "description": "Spicy chicken curry",
      "price": 800,
      "category": "Curries",
      "restaurantId": "507f1f77bcf86cd799439099",
      "image": "path/to/image.jpg",
      "available": true
    },
    {
      "_id": "507f1f77bcf86cd799439013",
      "name": "Biryani",
      "description": "Fragrant rice with meat",
      "price": 600,
      "category": "Rice Dishes",
      "restaurantId": "507f1f77bcf86cd799439099"
    }
  ]
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has menu array", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('menu');
    pm.expect(Array.isArray(jsonData.menu)).to.be.true;
});

pm.test("Menu items have required fields", function () {
    var jsonData = pm.response.json();
    if (jsonData.menu.length > 0) {
        var item = jsonData.menu[0];
        pm.expect(item).to.have.property('_id');
        pm.expect(item).to.have.property('name');
        pm.expect(item).to.have.property('price');
        
        // Save first menu item ID for cart testing
        pm.environment.set('menu_item_id', item._id);
    }
});
```

---

## API #4: GET ALL RESTAURANTS
**Endpoint:** `GET {{base_url}}/api/restaurants`  
**Status Code:** 200  
**Auth:** None

### Request Headers
```
Content-Type: application/json
```

### Request Body
```
None
```

### Expected Response (200)
```json
{
  "restaurants": [
    {
      "_id": "507f1f77bcf86cd799439099",
      "name": "Food Palace",
      "description": "Premium Pakistani Restaurant",
      "address": "123 Main Street, Layyah",
      "phone": "03001234567",
      "rating": 4.5,
      "image": "path/to/image.jpg",
      "cuisines": ["Pakistani", "Biryani"]
    },
    {
      "_id": "507f1f77bcf86cd799439100",
      "name": "Taste of Home",
      "description": "Authentic Home Cooked Food",
      "address": "456 Oak Street, Layyah",
      "phone": "03009876543",
      "rating": 4.2
    }
  ]
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response is an array", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('restaurants');
    pm.expect(Array.isArray(jsonData.restaurants)).to.be.true;
});

pm.test("Restaurants have required fields", function () {
    var jsonData = pm.response.json();
    if (jsonData.restaurants.length > 0) {
        pm.expect(jsonData.restaurants[0]).to.have.property('_id');
        pm.expect(jsonData.restaurants[0]).to.have.property('name');
    }
});
```

---

## API #5: ADD ITEM TO CART
**Endpoint:** `POST {{base_url}}/api/cart`  
**Status Code:** 200  
**Auth:** Cookie (Session)

### Request Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "id": "{{menu_item_id}}",
  "name": "Chicken Karahi",
  "price": 800,
  "quantity": 2
}
```

### Expected Response (200)
```json
{
  "cart": {
    "items": [
      {
        "id": "507f1f77bcf86cd799439012",
        "name": "Chicken Karahi",
        "price": 800,
        "quantity": 2
      }
    ],
    "subtotal": 1600,
    "updatedAt": "2026-01-19T10:30:00.000Z"
  }
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has cart object", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('cart');
    pm.expect(jsonData.cart).to.have.property('items');
    pm.expect(jsonData.cart).to.have.property('subtotal');
});

pm.test("Item added to cart correctly", function () {
    var jsonData = pm.response.json();
    var items = jsonData.cart.items;
    pm.expect(items.length).to.be.greaterThan(0);
    pm.expect(items[0]).to.have.property('id');
    pm.expect(items[0]).to.have.property('quantity');
});
```

---

## API #6: GET CART
**Endpoint:** `GET {{base_url}}/api/cart`  
**Status Code:** 200  
**Auth:** Cookie (Session)

### Request Headers
```
Content-Type: application/json
```

### Request Body
```
None
```

### Expected Response (200)
```json
{
  "cart": {
    "items": [
      {
        "id": "507f1f77bcf86cd799439012",
        "name": "Chicken Karahi",
        "price": 800,
        "quantity": 2
      }
    ],
    "subtotal": 1600,
    "updatedAt": "2026-01-19T10:30:00.000Z"
  }
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has cart", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('cart');
    pm.expect(Array.isArray(jsonData.cart.items)).to.be.true;
});

pm.test("Cart has subtotal", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.cart).to.have.property('subtotal');
    pm.expect(typeof jsonData.cart.subtotal).to.equal('number');
});
```

---

## API #7: CREATE ORDER
**Endpoint:** `POST {{base_url}}/api/orders`  
**Status Code:** 201  
**Auth:** Cookie (Session) - **MUST be logged in**

### Request Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "deliveryFee": 50
}
```

### Expected Response (201)
```json
{
  "order": {
    "id": "507f1f77bcf86cd799439015",
    "status": "confirmed",
    "total": 1650
  }
}
```

### Tests Tab
```javascript
pm.test("Status code is 201", function () {
    pm.expect(pm.response.code).to.equal(201);
});

pm.test("Order created successfully", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('order');
    pm.expect(jsonData.order).to.have.property('id');
    pm.expect(jsonData.order.status).to.equal('confirmed');
});

pm.test("Order has total amount", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.order).to.have.property('total');
    pm.expect(typeof jsonData.order.total).to.equal('number');
    
    pm.environment.set('order_id', jsonData.order.id);
});
```

---

## API #8: GET USER ORDERS
**Endpoint:** `GET {{base_url}}/api/orders`  
**Status Code:** 200  
**Auth:** Cookie (Session) - **MUST be logged in**

### Request Headers
```
Content-Type: application/json
```

### Request Body
```
None
```

### Expected Response (200)
```json
{
  "orders": [
    {
      "id": "507f1f77bcf86cd799439015",
      "status": "confirmed",
      "total": 1650,
      "createdAt": "2026-01-19T10:30:00.000Z",
      "updatedAt": "2026-01-19T10:30:00.000Z"
    }
  ]
}
```

### Tests Tab
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response has orders array", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('orders');
    pm.expect(Array.isArray(jsonData.orders)).to.be.true;
});

pm.test("Orders have required fields", function () {
    var jsonData = pm.response.json();
    if (jsonData.orders.length > 0) {
        var order = jsonData.orders[0];
        pm.expect(order).to.have.property('id');
        pm.expect(order).to.have.property('status');
        pm.expect(order).to.have.property('total');
        pm.expect(order).to.have.property('createdAt');
    }
});
```

---

## EXECUTION ORDER IN POSTMAN

Run tests in this sequence:

1. ✅ **Register User** - Creates user account
2. ✅ **Login** - Authenticates and gets session cookie
3. ✅ **Get Menu Items** - Fetches menu (extracts menu_item_id)
4. ✅ **Get Restaurants** - Fetches restaurants
5. ✅ **Add to Cart** - Uses menu_item_id from step 3
6. ✅ **Get Cart** - Verifies cart contents
7. ✅ **Create Order** - Creates order from cart items
8. ✅ **Get Orders** - Fetches user's orders

---

## KEY POINTS FOR SUCCESS

### Authentication
- First 4 APIs don't need authentication
- APIs 5-8 require user to be logged in (cookie session)
- Cookies are automatically handled by Postman when set

### Response Headers
All endpoints return: `Content-Type: application/json`

### Error Handling
- 400: Missing/Invalid fields
- 401: Unauthorized (not logged in for protected routes)
- 409: Email already registered
- 201: Created successfully
- 200: OK - Request successful
