# LayyahEats Software Testing and Quality Assurance Project - User Guide

## Project Overview
This user guide provides step-by-step instructions for completing the Software Testing and Quality Assurance project on LayyahEats, an Online Food Delivery web application built with Next.js. The project focuses on applying testing concepts to a real-world system, covering manual testing, automation, API testing, bug reporting, and documentation.

**Project Weightage**: 30-40%  
**Instructor**: Faisal Hafeez  
**Semester**: 5th Semester  
**Course**: Software Testing and Quality Assurance  

**System Chosen**: Web-based application (Online Food Delivery - LayyahEats)  
**Key Features Tested**:
- User Authentication (Login, Register, Logout)
- Restaurant & Menu Browsing
- Shopping Cart Management
- Ordering & Payment (Cash on Delivery, Stripe)
- Order Tracking
- Admin Dashboard (Menu, Orders, Users Management)

## Prerequisites
- **System Requirements**: Windows 11, Node.js installed (for running the app)
- **Tools Needed**:
  - Postman (for API testing)
  - Playwright (for automation)
  - Jira account (for bug reporting) or simulate with docs
  - VS Code or any text editor
- **Application Setup**:
  1. Clone or navigate to the project directory: `d:/Collaborating with MT/Online Food delivery`
  2. Install dependencies: `npm install`
  3. Set up environment variables in `.env.local` (MongoDB URI, Stripe keys, etc.)
  4. Run the app: `npm run dev` (access at http://localhost:3000)

## Project Structure
All project deliverables are organized in the `QA/` folder:
- `QA/Manual_Testing/` - Test Plan and Test Cases
- `QA/Automation/` - Playwright scripts and reports
- `QA/API_Testing/` - Postman collection
- `QA/Bug_Reports/` - Defect reports
- `QA/Reports/` - Summary reports and traceability matrix
- `QA/User_Guide.md` - This guide

## 1. Manual Testing
Manual testing involves executing test cases without automation tools. You must create a Test Plan and at least 20-25 test cases, including functional and negative scenarios.

### Step 1: Create Test Plan
Create `QA/Manual_Testing/Test_Plan.md` with the following content:

```markdown
# Test Plan for LayyahEats

## 1. Introduction
- **Project Name**: LayyahEats
- **Test Objective**: Ensure all features work correctly, identify defects, and validate quality.
- **Scope**: User features (auth, browsing, cart, ordering), Admin features (dashboard management).
- **Out of Scope**: Third-party integrations (Stripe, SMS) unless directly impacted.

## 2. Test Strategy
- **Testing Types**: Functional, Negative, UI/UX, Compatibility.
- **Test Environment**: Local development (http://localhost:3000), Browser: Chrome.
- **Roles**: Tester (You), Developer (Simulated).
- **Risks**: Data loss in database, payment failures.

## 3. Test Schedule
- Week 1: Manual test case creation and execution.
- Week 2: Automation and API testing.
- Week 3: Bug reporting and documentation.

## 4. Deliverables
- Test Cases document
- Screenshots of test execution
- Test Summary Report
```

### Step 2: Create Test Cases
Create `QA/Manual_Testing/Test_Cases.md` with 20-25 test cases. Example structure:

```markdown
# Test Cases for LayyahEats

## Test Case ID: TC001
- **Title**: User Login with Valid Credentials
- **Description**: Verify user can log in with correct email and password.
- **Preconditions**: User account exists.
- **Steps**:
  1. Navigate to login page.
  2. Enter valid email and password.
  3. Click Login.
- **Expected Result**: User logged in, redirected to homepage.
- **Actual Result**: [Fill after execution]
- **Status**: Pass/Fail
- **Priority**: High
- **Type**: Functional
- **Screenshot**: [Attach path]

## Test Case ID: TC002
- **Title**: User Login with Invalid Credentials
- **Description**: Verify error message for wrong credentials.
- **Preconditions**: None.
- **Steps**:
  1. Navigate to login page.
  2. Enter invalid email/password.
  3. Click Login.
- **Expected Result**: Error message displayed.
- **Actual Result**: [Fill after execution]
- **Status**: Pass/Fail
- **Priority**: High
- **Type**: Negative
- **Screenshot**: [Attach path]

[Continue with 20-25 cases covering all features: Registration, Menu Browsing, Add to Cart, Place Order, Order Tracking, Admin Menu Management, etc.]
```

### Step 3: Execute Tests
1. Run `npm run dev` to start the app.
2. Execute each test case manually.
3. Capture screenshots for evidence (save in `QA/Manual_Testing/screenshots/`).
4. Update Actual Result and Status in the Test Cases document.

## 2. Test Automation
Automate 8-10 critical test cases using Playwright.

### Step 1: Install Playwright
Run: `npm install -D @playwright/test`

### Step 2: Set Up Configuration
Create `playwright.config.ts` in root:

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './QA/Automation',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
```

### Step 3: Create Automation Scripts
Create scripts in `QA/Automation/`. Example: `login.spec.ts`

```typescript
import { test, expect } from '@playwright/test';

test('User Login', async ({ page }) => {
  await page.goto('/');
  await page.click('text=Login');
  await page.fill('input[name="email"]', 'test@example.com');
  await page.fill('input[name="password"]', 'password123');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL('/'); // Assuming redirect to home
});

test('Add to Cart', async ({ page }) => {
  await page.goto('/menu');
  await page.click('text=Add to Cart');
  await expect(page.locator('.cart-count')).toContainText('1');
});

// Add 8-10 more tests for critical features.
```

### Step 4: Run Tests and Generate Reports
1. Run: `npx playwright test`
2. View reports: `npx playwright show-report`
3. Save HTML report in `QA/Automation/reports/`

## 3. API Testing
Test APIs using Postman with 6-8 requests.

### Step 1: Identify APIs
Key APIs from `src/app/api/`:
- Auth: `/api/auth/login`, `/api/auth/register`
- Cart: `/api/cart`
- Orders: `/api/orders`, `/api/orders/[orderId]`
- Menu: `/api/menu`
- Admin: `/api/admin/*`

### Step 2: Create Postman Collection
1. Open Postman, create a new collection "LayyahEats API Tests".
2. Add requests:
   - **Login (POST)**: URL: http://localhost:3000/api/auth/login, Body: {"email":"test@example.com","password":"pass"}
   - **Register (POST)**: URL: http://localhost:3000/api/auth/register, Body: user data
   - **Get Menu (GET)**: URL: http://localhost:3000/api/menu
   - **Add to Cart (POST)**: URL: http://localhost:3000/api/cart, Body: item data
   - **Place Order (POST)**: URL: http://localhost:3000/api/orders, Body: order data
   - **Get Orders (GET)**: URL: http://localhost:3000/api/orders
   - **Admin Get Users (GET)**: URL: http://localhost:3000/api/admin/users
   - **Track Order (GET)**: URL: http://localhost:3000/api/orders/123/tracking

3. Add Tests (Assertions) in each request:
   ```javascript
   pm.test("Status code is 200", function () {
       pm.response.to.have.status(200);
   });
   pm.test("Response has data", function () {
       var jsonData = pm.response.json();
       pm.expect(jsonData).to.be.an('object');
   });
   ```

4. Use Environment Variables: Create "LayyahEats" environment with variables like `base_url = http://localhost:3000`

### Step 3: Export Collection
Export as JSON and save as `QA/API_Testing/Postman_Collection.json`

## 4. Bug Reporting & Defect Management
Simulate/find 5-7 defects and report them.

### Step 1: Identify/Simulate Defects
Examples:
1. Login fails with valid credentials (API error).
2. Cart doesn't update quantity.
3. Order placement shows wrong total.
4. Admin can't delete menu item.
5. UI breaks on mobile view.
6. Payment fails with Stripe.
7. Order tracking doesn't update status.

### Step 2: Report in Jira or Docs
If using Jira:
1. Create account at jira.com.
2. Create project "LayyahEats Bugs".
3. Log defects with fields: Summary, Description, Steps to Reproduce, Expected/Actual Result, Severity, Priority, Attachments (screenshots).

Simulate in docs: Create `QA/Bug_Reports/Bug_001.md` for each:

```markdown
# Bug Report: BR001
- **Title**: Login Fails with Valid Credentials
- **Description**: User cannot log in despite correct details.
- **Steps to Reproduce**:
  1. Go to login page.
  2. Enter valid email/password.
  3. Click submit.
- **Expected Result**: Successful login.
- **Actual Result**: Error message.
- **Severity**: High
- **Priority**: High
- **Status**: Open
- **Screenshot**: path/to/screenshot.png
- **Environment**: Chrome, Localhost
```

## 5. Quality Assurance Documentation
Create summary reports and traceability.

### Step 1: Test Summary Report
Create `QA/Reports/Test_Summary_Report.md`:

```markdown
# Test Summary Report

## Executive Summary
Testing completed for LayyahEats with focus on functionality and quality.

## Test Metrics
- Total Test Cases: 25
- Passed: 22
- Failed: 3
- Blocked: 0
- Coverage: 100% of features

## Test Results by Module
- Authentication: 5/5 Passed
- Cart Management: 4/5 Passed
- Ordering: 5/5 Passed
- Admin: 4/5 Passed

## Recommendations
Fix failed tests, improve error handling.
```

### Step 2: Defect Summary Report
Create `QA/Reports/Defect_Summary_Report.md`:

```markdown
# Defect Summary Report

## Defect Metrics
- Total Defects: 7
- Open: 3
- Closed: 4
- Critical: 2
- High: 3
- Medium: 2

## Defects by Module
- UI: 3
- API: 2
- Functionality: 2

## Trends
Most defects in cart and payment modules.
```

### Step 3: Traceability Matrix
Create `QA/Reports/Traceability_Matrix.md`:

```markdown
# Traceability Matrix

| Requirement ID | Requirement Description | Test Case ID | Defect ID | Status |
|----------------|-------------------------|--------------|-----------|--------|
| R001 | User Login | TC001, TC002 | BR001 | Covered |
| R002 | Add to Cart | TC005 | None | Covered |
| ... | ... | ... | ... | ... |
```

Link requirements from `Software_Requirement_Description.md` to test cases and defects.

## 6. Presentation & Deliverables
### Presentation Slides
Create `QA/Presentation_Slides.md` with outline:

```markdown
# LayyahEats Testing Project Presentation

## Slide 1: Introduction
- Project Overview
- System Description

## Slide 2: Manual Testing
- Test Plan Overview
- Test Case Demo (show 5 cases)
- Execution Evidence

## Slide 3: Automation
- Playwright Setup
- Demo Script Execution
- Report Screenshots

## Slide 4: API Testing
- Postman Demo
- Assertions and Variables

## Slide 5: Bug Reporting
- Jira/Simulated Reports
- Defect Lifecycle

## Slide 6: Documentation
- Reports and Matrix

## Slide 7: Conclusion
- Lessons Learned
- Future Improvements
```

### Final Deliverables
- Project Report (PDF of all docs)
- Test Cases (MD/PDF)
- Automation Scripts (ZIP)
- Postman Collection (JSON)
- Jira Screenshots/Docs
- Presentation Slides (PDF)

## Evaluation Tips
- Ensure all components are covered.
- Demonstrate live execution in presentation.
- Use professional formatting.
- Cite sources if any.

## Troubleshooting
- If app doesn't run: Check `.env.local` for correct variables.
- Playwright issues: Run `npx playwright install` for browsers.
- API errors: Ensure MongoDB is running.

This guide covers everything as per instructions. Follow step-by-step, and update TODO.md as you complete tasks. Good luck!
