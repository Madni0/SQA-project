import { test, expect } from '@playwright/test';

test.describe('Ordering and Payment Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000');
    
    // Login
    await page.click('text=Login');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    
    // Wait for login to complete
    await page.waitForURL(/.*dashboard|.*home/);
  });

  test('TC014: Place Order with Cash on Delivery', async ({ page }) => {
    // Add items to cart
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Navigate to cart and checkout
    await page.click('text=Cart');
    
    // Click checkout
    const checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Place Order")');
    await checkoutButton.click();
    
    // Wait for checkout page
    await page.waitForTimeout(2000);
    
    // Select delivery address (if applicable)
    const addressSelect = page.locator('select[name="address"], [class*="address"]');
    if (await addressSelect.count() > 0) {
      await addressSelect.first().click();
      await page.locator('text=/select|choose/i').first().click();
    }
    
    // Select Cash on Delivery payment method
    const codRadio = page.locator('input[value="COD"], input[value="cash"], label:has-text("Cash on Delivery")');
    if (await codRadio.count() > 0) {
      await codRadio.first().click();
    }
    
    // Place order
    const placeOrderButton = page.locator('button:has-text("Place Order"), button:has-text("Confirm Order")');
    await placeOrderButton.click();
    
    // Wait for confirmation
    await page.waitForTimeout(2000);
    
    // Verify order confirmation
    const confirmationText = page.locator('text=/confirmation|order placed|order id/i');
    await expect(confirmationText).toBeVisible({ timeout: 5000 });
  });

  test('TC015: Place Order with Stripe Payment', async ({ page }) => {
    // Add items to cart
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Navigate to checkout
    await page.click('text=Cart');
    const checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Place Order")');
    await checkoutButton.click();
    
    await page.waitForTimeout(2000);
    
    // Select Stripe payment
    const stripeRadio = page.locator('input[value="stripe"], input[value="card"], label:has-text("Credit Card")');
    if (await stripeRadio.count() > 0) {
      await stripeRadio.first().click();
    }
    
    // Click pay or proceed to payment
    const payButton = page.locator('button:has-text("Pay"), button:has-text("Proceed")');
    await payButton.click();
    
    // Wait for Stripe popup or redirect
    await page.waitForTimeout(2000);
    
    // Check if Stripe modal or iframe appeared
    const stripeElement = page.locator('[class*="stripe"], iframe[name*="stripe"], iframe[src*="stripe"]');
    const isStripeVisible = await stripeElement.count() > 0;
    
    expect(isStripeVisible).toBe(true);
  });

  test('TC016: Verify Order Calculation with Delivery Fee', async ({ page }) => {
    // Add items
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    // Get item price
    const itemPrice = page.locator('[class*="price"]').first();
    const price = await itemPrice.innerText();
    const itemAmount = parseFloat(price.replace(/[^0-9.]/g, ''));
    
    // Add item to cart
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Navigate to checkout
    await page.click('text=Cart');
    const checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Place Order")');
    await checkoutButton.click();
    
    await page.waitForTimeout(2000);
    
    // Select delivery type
    const deliverySelect = page.locator('select[name*="delivery"], [class*="delivery"]');
    if (await deliverySelect.count() > 0) {
      await deliverySelect.first().click();
      await page.locator('text=/standard|regular|normal/i').first().click();
    }
    
    // Get delivery fee and total
    const subtotal = page.locator('[class*="subtotal"], text=/subtotal/i');
    const deliveryFee = page.locator('[class*="delivery-fee"], text=/delivery/i');
    const total = page.locator('[class*="total"], text=/total/i');
    
    if (await subtotal.count() > 0 && await deliveryFee.count() > 0 && await total.count() > 0) {
      const subtotalText = await subtotal.innerText();
      const feeText = await deliveryFee.innerText();
      const totalText = await total.innerText();
      
      // Extract numbers
      const sub = parseFloat(subtotalText.replace(/[^0-9.]/g, ''));
      const fee = parseFloat(feeText.replace(/[^0-9.]/g, ''));
      const tot = parseFloat(totalText.replace(/[^0-9.]/g, ''));
      
      // Verify calculation
      expect(Math.abs((sub + fee) - tot)).toBeLessThan(1);
    }
  });

  test('TC017: View Order Confirmation', async ({ page }) => {
    // Place an order
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    await page.click('text=Cart');
    const checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Place Order")');
    await checkoutButton.click();
    
    await page.waitForTimeout(2000);
    
    // Select COD
    const codRadio = page.locator('input[value="COD"], input[value="cash"]');
    if (await codRadio.count() > 0) {
      await codRadio.first().click();
    }
    
    // Place order
    const placeOrderButton = page.locator('button:has-text("Place Order"), button:has-text("Confirm Order")');
    await placeOrderButton.click();
    
    await page.waitForTimeout(2000);
    
    // Verify confirmation details
    const orderId = page.locator('[class*="order-id"], text=/order id|order #/i');
    const deliveryTime = page.locator('[class*="delivery-time"], text=/delivery/i');
    const paymentStatus = page.locator('[class*="payment-status"], text=/payment/i');
    
    await expect(orderId).toBeVisible({ timeout: 3000 });
    
    if (await deliveryTime.count() > 0) {
      await expect(deliveryTime).toBeVisible();
    }
    
    if (await paymentStatus.count() > 0) {
      await expect(paymentStatus).toBeVisible();
    }
  });

  test('TC018: Track Order Status', async ({ page }) => {
    // Navigate to orders/tracking section
    await page.goto('http://localhost:3000');
    
    // Click on My Orders or similar menu
    const myOrdersLink = page.locator('text=My Orders, text=Orders, text=Track Order');
    if (await myOrdersLink.count() > 0) {
      await myOrdersLink.first().click();
    } else {
      // Navigate directly
      await page.goto('http://localhost:3000/orders');
    }
    
    // Wait for orders to load
    await page.waitForTimeout(2000);
    
    // Check if orders are displayed
    const orders = page.locator('[class*="order"], [class*="order-item"]');
    const orderCount = await orders.count();
    
    if (orderCount > 0) {
      // Click on first order
      const firstOrder = orders.first();
      await firstOrder.click();
      
      // Wait for order details
      await page.waitForTimeout(1000);
      
      // Verify order status is shown
      const status = page.locator('[class*="status"], text=/pending|preparing|delivery|delivered/i');
      await expect(status).toBeVisible({ timeout: 2000 });
    }
  });

  test('TC019: View Order History', async ({ page }) => {
    // Navigate to orders page
    await page.goto('http://localhost:3000');
    
    const myOrdersLink = page.locator('text=My Orders, text=Orders, text=Track Order');
    if (await myOrdersLink.count() > 0) {
      await myOrdersLink.first().click();
    } else {
      await page.goto('http://localhost:3000/orders');
    }
    
    // Wait for page to load
    await page.waitForTimeout(2000);
    
    // Verify orders are displayed in a list
    const orderList = page.locator('[class*="order-list"], [class*="orders"]');
    await expect(orderList).toBeVisible({ timeout: 3000 });
    
    // Check for order details in list
    const orderIds = page.locator('[class*="order-id"], text=/order #|order id/i');
    const dates = page.locator('[class*="date"], text=/date/i');
    const amounts = page.locator('[class*="amount"], text=/total|amount/i');
    
    if (await orderIds.count() > 0) {
      await expect(orderIds.first()).toBeVisible();
    }
  });
});
