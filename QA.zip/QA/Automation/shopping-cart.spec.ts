import { test, expect } from '@playwright/test';

test.describe('Shopping Cart Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000');
    
    // Login before each test
    await page.click('text=Login');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    
    // Wait for login to complete
    await page.waitForURL(/.*dashboard|.*home/);
  });

  test('TC006: View Homepage with Available Restaurants', async ({ page }) => {
    // Navigate to homepage after login
    await page.goto('http://localhost:3000');
    
    // Wait for restaurants to load
    await page.waitForTimeout(2000);
    
    // Check if restaurant cards are visible
    const restaurantCards = page.locator('[class*="restaurant"], [class*="card"]');
    const count = await restaurantCards.count();
    
    expect(count).toBeGreaterThan(0);
    
    // Verify restaurant details are displayed
    const restaurantName = page.locator('[class*="restaurant-name"]');
    await expect(restaurantName.first()).toBeVisible();
  });

  test('TC007: Search for Restaurant by Name', async ({ page }) => {
    // Find and click search bar
    const searchBar = page.locator('input[placeholder*="search"], input[type="search"]');
    await searchBar.fill('Biryani House');
    
    // Press enter or wait for search results
    await searchBar.press('Enter');
    await page.waitForTimeout(1000);
    
    // Verify search results are filtered
    const results = page.locator('[class*="restaurant"], [class*="result"]');
    const resultsText = await page.locator('body').innerText();
    
    expect(resultsText).toContain('Biryani House');
  });

  test('TC008: View Restaurant Menu', async ({ page }) => {
    // Navigate to restaurants
    await page.goto('http://localhost:3000');
    
    // Click on first restaurant
    const restaurantCard = page.locator('[class*="restaurant-card"]').first();
    await restaurantCard.click();
    
    // Wait for menu to load
    await page.waitForTimeout(2000);
    
    // Verify menu items are displayed
    const menuItems = page.locator('[class*="menu-item"], [class*="item"]');
    const itemCount = await menuItems.count();
    
    expect(itemCount).toBeGreaterThan(0);
    
    // Verify item details
    const itemName = page.locator('[class*="item-name"]');
    await expect(itemName.first()).toBeVisible();
  });

  test('TC009: Add Single Item to Cart', async ({ page }) => {
    // Navigate to restaurant menu
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    
    // Wait for menu to load
    await page.waitForTimeout(2000);
    
    // Click add to cart button
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Verify item added (check for confirmation message or cart update)
    const cartBadge = page.locator('[class*="cart-count"], [class*="badge"]');
    await expect(cartBadge).toContainText('1');
  });

  test('TC010: Increase Item Quantity in Cart', async ({ page }) => {
    // First add item to cart
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Navigate to cart
    await page.click('text=Cart');
    
    // Find increase quantity button
    const increaseButton = page.locator('button[aria-label*="increase"], button:has-text("+")').first();
    
    // Get current quantity
    const quantity = page.locator('[class*="quantity"]').first();
    const initialQty = await quantity.innerText();
    
    // Click increase button
    await increaseButton.click();
    
    // Verify quantity increased
    const newQty = await quantity.innerText();
    expect(parseInt(newQty)).toBeGreaterThan(parseInt(initialQty));
  });

  test('TC011: Decrease Item Quantity in Cart', async ({ page }) => {
    // Add item and navigate to cart
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    // Add item twice
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    await page.waitForTimeout(500);
    await addButton.click();
    
    // Navigate to cart
    await page.click('text=Cart');
    
    // Decrease quantity
    const decreaseButton = page.locator('button[aria-label*="decrease"], button:has-text("-")').first();
    const quantity = page.locator('[class*="quantity"]').first();
    
    const beforeQty = await quantity.innerText();
    await decreaseButton.click();
    const afterQty = await quantity.innerText();
    
    expect(parseInt(afterQty)).toBeLessThan(parseInt(beforeQty));
  });

  test('TC012: Remove Item from Cart', async ({ page }) => {
    // Add item to cart
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButton = page.locator('button:has-text("Add to Cart")').first();
    await addButton.click();
    
    // Navigate to cart
    await page.click('text=Cart');
    
    // Get initial item count
    const items = page.locator('[class*="cart-item"], [class*="item-row"]');
    const initialCount = await items.count();
    
    // Click remove button
    const removeButton = page.locator('button[aria-label*="remove"], button:has-text("Remove")').first();
    await removeButton.click();
    
    // Verify item removed
    const newCount = await items.count();
    expect(newCount).toBeLessThan(initialCount);
  });

  test('TC013: Clear Entire Shopping Cart', async ({ page }) => {
    // Add multiple items
    await page.goto('http://localhost:3000');
    await page.locator('[class*="restaurant-card"]').first().click();
    await page.waitForTimeout(2000);
    
    const addButtons = page.locator('button:has-text("Add to Cart")');
    const count = Math.min(await addButtons.count(), 2);
    
    for (let i = 0; i < count; i++) {
      await addButtons.nth(i).click();
      await page.waitForTimeout(300);
    }
    
    // Navigate to cart
    await page.click('text=Cart');
    
    // Click clear cart button
    const clearButton = page.locator('button:has-text("Clear Cart")');
    await clearButton.click();
    
    // Confirm if prompted
    if (await page.locator('text=Confirm').isVisible({ timeout: 1000 })) {
      await page.click('text=Confirm');
    }
    
    // Verify cart is empty
    const emptyMessage = page.locator('text=/empty|no items/i');
    await expect(emptyMessage).toBeVisible();
  });

  test('TC028: Place Order with Empty Cart (Negative Test)', async ({ page }) => {
    // Navigate to cart without adding items
    await page.goto('http://localhost:3000');
    await page.click('text=Cart');
    
    // Try to checkout
    const checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Place Order")');
    const isDisabled = await checkoutButton.isDisabled();
    
    expect(isDisabled).toBe(true);
    
    // Or check for empty cart message
    const emptyMessage = page.locator('text=/empty|no items/i');
    const isEmpty = await emptyMessage.isVisible({ timeout: 1000 });
    
    expect(isEmpty || isDisabled).toBe(true);
  });
});
