# Test Cases for LayyahEats - Online Food Delivery Application

## Test Case ID: TC001
- **Title**: User Login with Valid Credentials
- **Description**: Verify user can successfully log in using valid email and password.
- **Preconditions**: User account exists with email: test@example.com and password: password123
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to http://localhost:3000
  2. Click on "Login" button/link
  3. Enter email: test@example.com
  4. Enter password: password123
  5. Click "Login" button
- **Expected Result**: User is authenticated successfully and redirected to the homepage or dashboard
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC002
- **Title**: User Login with Invalid Email
- **Description**: Verify error message is displayed when logging in with non-existent email
- **Preconditions**: None
- **Priority**: High
- **Type**: Negative
- **Steps**:
  1. Navigate to login page
  2. Enter email: nonexistent@example.com
  3. Enter password: password123
  4. Click "Login" button
- **Expected Result**: Error message displayed: "User not found" or "Invalid credentials"
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC003
- **Title**: User Login with Wrong Password
- **Description**: Verify error message is displayed for incorrect password
- **Preconditions**: User account exists with email: test@example.com
- **Priority**: High
- **Type**: Negative
- **Steps**:
  1. Navigate to login page
  2. Enter email: test@example.com
  3. Enter password: wrongpassword
  4. Click "Login" button
- **Expected Result**: Error message displayed: "Invalid credentials" or "Incorrect password"
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC004
- **Title**: User Registration with Valid Data
- **Description**: Verify new user can successfully register with valid information
- **Preconditions**: New email not previously registered
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to login/registration page
  2. Click "Register" button
  3. Enter name: John Doe
  4. Enter phone: 03001234567
  5. Enter email: newuser@example.com
  6. Enter password: SecurePass123
  7. Confirm password: SecurePass123
  8. Click "Register" button
- **Expected Result**: User account created successfully, welcome message displayed, user redirected to homepage or confirmation page
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC005
- **Title**: User Registration with Existing Email
- **Description**: Verify error message when registering with already registered email
- **Preconditions**: Email test@example.com already registered
- **Priority**: High
- **Type**: Negative
- **Steps**:
  1. Navigate to registration page
  2. Fill all fields with valid data
  3. Enter email: test@example.com (already registered)
  4. Click "Register" button
- **Expected Result**: Error message displayed: "Email already exists" or "This email is already registered"
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC006
- **Title**: View Homepage with Available Restaurants
- **Description**: Verify homepage displays list of available restaurants
- **Preconditions**: User is logged in
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Log in with valid credentials
  2. Homepage loads automatically
  3. Observe restaurant listings
- **Expected Result**: Homepage displays restaurant cards with name, image, rating, delivery fee, and cuisine type
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC007
- **Title**: Search for Restaurant by Name
- **Description**: Verify user can search for restaurants using search functionality
- **Preconditions**: User is logged in, multiple restaurants available
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to homepage
  2. Click on search bar
  3. Enter restaurant name: "Biryani House"
  4. Press Enter or click search button
- **Expected Result**: Search results display only restaurants matching "Biryani House", irrelevant restaurants filtered out
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC008
- **Title**: View Restaurant Menu
- **Description**: Verify user can view menu items of a selected restaurant
- **Preconditions**: User is logged in, restaurants are available
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to homepage
  2. Click on a restaurant card
  3. Restaurant menu page loads
  4. Observe menu items displayed
- **Expected Result**: Menu items display with item name, description, price, image, and add to cart button
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC009
- **Title**: Add Single Item to Cart
- **Description**: Verify user can add a menu item to shopping cart
- **Preconditions**: User is logged in, menu items are available
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to restaurant menu
  2. Click "Add to Cart" button for a menu item (e.g., Biryani - Rs. 500)
  3. Confirm item is added
- **Expected Result**: Item added to cart, cart count incremented, confirmation message displayed
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC010
- **Title**: Increase Item Quantity in Cart
- **Description**: Verify user can increase quantity of item in cart
- **Preconditions**: Item exists in cart
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to shopping cart
  2. Locate item with quantity 1
  3. Click "+" or "Increase Quantity" button
  4. Verify quantity changed to 2
- **Expected Result**: Quantity increases to 2, total price updated (original price × 2)
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC011
- **Title**: Decrease Item Quantity in Cart
- **Description**: Verify user can decrease quantity of item in cart
- **Preconditions**: Item exists in cart with quantity ≥ 2
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to shopping cart with item (quantity: 2)
  2. Click "-" or "Decrease Quantity" button
  3. Verify quantity changed to 1
- **Expected Result**: Quantity decreases to 1, total price updated accordingly
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC012
- **Title**: Remove Item from Cart
- **Description**: Verify user can remove a specific item from cart
- **Preconditions**: Item exists in cart
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to shopping cart
  2. Click "Remove" or "Delete" button for an item
  3. Confirm removal action if prompted
- **Expected Result**: Item removed from cart, cart count decreased, total price updated
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC013
- **Title**: Clear Entire Shopping Cart
- **Description**: Verify user can clear all items from cart
- **Preconditions**: Cart contains multiple items
- **Priority**: Medium
- **Type**: Functional
- **Steps**:
  1. Navigate to shopping cart with items
  2. Click "Clear Cart" or "Remove All" button
  3. Confirm action if prompted
- **Expected Result**: All items removed, cart becomes empty, message displayed: "Your cart is empty"
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC014
- **Title**: Place Order with Cash on Delivery
- **Description**: Verify user can successfully place order using Cash on Delivery payment method
- **Preconditions**: User is logged in, cart contains items, delivery address is set
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Add items to cart
  2. Navigate to cart
  3. Click "Proceed to Checkout"
  4. Select delivery address
  5. Select "Cash on Delivery" payment method
  6. Click "Place Order" button
- **Expected Result**: Order placed successfully, order confirmation displayed with order ID, order date, and estimated delivery time
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC015
- **Title**: Place Order with Stripe Payment
- **Description**: Verify user can initiate order placement with Stripe payment option
- **Preconditions**: User is logged in, cart contains items, Stripe is configured
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Add items to cart
  2. Navigate to checkout
  3. Select delivery address
  4. Select "Credit Card" or "Stripe" payment method
  5. Click "Pay Now" or proceed to payment
  6. Stripe payment dialog appears
- **Expected Result**: Stripe payment dialog loads, user can enter payment details
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC016
- **Title**: Verify Order Calculation with Delivery Fee
- **Description**: Verify correct calculation of order total including delivery fee
- **Preconditions**: User has items in cart
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Add items to cart (total: Rs. 1000)
  2. Navigate to checkout
  3. Select delivery type (e.g., Standard - Rs. 50)
  4. Observe total calculation
- **Expected Result**: Order total = Item subtotal (1000) + Delivery Fee (50) = 1050. Calculation displayed correctly
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC017
- **Title**: View Order Confirmation
- **Description**: Verify order confirmation details are displayed after successful order placement
- **Preconditions**: Order has been placed successfully
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Place order successfully
  2. Confirmation page loads
  3. Observe confirmation details
- **Expected Result**: Page displays order ID, items ordered, delivery address, estimated time, and payment status
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC018
- **Title**: Track Order Status
- **Description**: Verify user can track order status with real-time updates
- **Preconditions**: User has placed an order
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to "My Orders" or order history
  2. Click on an active order
  3. View order details and status
- **Expected Result**: Page displays order status (e.g., Pending, Preparing, Out for Delivery, Delivered) with updated timestamp
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC019
- **Title**: View Order History
- **Description**: Verify user can view all past orders
- **Preconditions**: User is logged in and has placed multiple orders
- **Priority**: Medium
- **Type**: Functional
- **Steps**:
  1. Click on "My Orders" or "Order History"
  2. Page loads with list of all orders
  3. Observe past orders with details
- **Expected Result**: Page displays all previous orders with order ID, date, items, total amount, and status
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC020
- **Title**: User Logout
- **Description**: Verify user can successfully logout from application
- **Preconditions**: User is logged in
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Click on user profile menu
  2. Click "Logout" option
  3. Confirm logout action if prompted
- **Expected Result**: User logged out successfully, redirected to login page, session terminated
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC021
- **Title**: Admin Login with Valid Credentials
- **Description**: Verify admin can login with valid admin credentials
- **Preconditions**: Admin account exists with email: admin@example.com
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to login page
  2. Enter admin email: admin@example.com
  3. Enter admin password: adminpass123
  4. Click "Login"
- **Expected Result**: Admin user logged in successfully, redirected to admin dashboard
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC022
- **Title**: Admin Add Menu Item
- **Description**: Verify admin can add a new menu item to restaurant
- **Preconditions**: Admin is logged in
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to admin dashboard
  2. Click "Menu Management" or "Add Item"
  3. Fill item details: Name: "Chicken Karahi", Price: 800, Description: "Spicy chicken curry", Category: "Curries"
  4. Upload item image
  5. Click "Save" or "Add Item" button
- **Expected Result**: Menu item added successfully, appears in restaurant menu, success message displayed
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC023
- **Title**: Admin Edit Menu Item
- **Description**: Verify admin can edit existing menu item details
- **Preconditions**: Admin is logged in, menu item exists
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to Menu Management
  2. Click "Edit" on a menu item
  3. Update price: 900 (from 800)
  4. Update description
  5. Click "Save" button
- **Expected Result**: Menu item updated successfully, changes reflected in menu, confirmation message displayed
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC024
- **Title**: Admin Delete Menu Item
- **Description**: Verify admin can delete a menu item
- **Preconditions**: Admin is logged in, menu item exists
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to Menu Management
  2. Click "Delete" on a menu item
  3. Confirm deletion if prompted
- **Expected Result**: Menu item deleted successfully, removed from menu list, confirmation message displayed
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC025
- **Title**: Admin View Orders Dashboard
- **Description**: Verify admin can view all orders in management dashboard
- **Preconditions**: Admin is logged in, orders exist in system
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to admin dashboard
  2. Click "Orders" or "Order Management"
  3. Observe orders list
- **Expected Result**: Dashboard displays all orders with order ID, customer name, items, status, order date, and total amount
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC026
- **Title**: Admin Update Order Status
- **Description**: Verify admin can update order status
- **Preconditions**: Admin is logged in, order exists
- **Priority**: High
- **Type**: Functional
- **Steps**:
  1. Navigate to Orders Management
  2. Click on an order
  3. Change status from "Pending" to "Preparing"
  4. Click "Update" button
- **Expected Result**: Order status updated successfully, changes reflected in customer's order tracking page
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC027
- **Title**: Admin View Registered Users
- **Description**: Verify admin can view list of all registered users
- **Preconditions**: Admin is logged in, users exist in system
- **Priority**: Medium
- **Type**: Functional
- **Steps**:
  1. Navigate to admin dashboard
  2. Click "User Management" or "Users"
  3. Observe users list
- **Expected Result**: Page displays all registered users with name, email, phone, registration date, and account status
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC028
- **Title**: Place Order with Empty Cart (Negative Test)
- **Description**: Verify system prevents placing order with empty cart
- **Preconditions**: User is logged in, cart is empty
- **Priority**: High
- **Type**: Negative
- **Steps**:
  1. Navigate to empty shopping cart
  2. Try to click "Proceed to Checkout" or "Place Order"
- **Expected Result**: Button is disabled or error message displayed: "Cart is empty, add items to place order"
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC029
- **Title**: Login with Blank Email and Password
- **Description**: Verify validation for empty login fields
- **Preconditions**: User is on login page
- **Priority**: Medium
- **Type**: Negative
- **Steps**:
  1. Leave email and password fields blank
  2. Click "Login" button
- **Expected Result**: Validation error displayed: "Email and password are required" or similar validation message
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Screenshot**: [Add path after execution]
- **Notes**: [Any additional observations]

## Test Case ID: TC030
- **Title**: Response Time for Page Load
- **Description**: Verify homepage loads within acceptable time (< 3 seconds)
- **Preconditions**: User is on login page with active internet connection
- **Priority**: Medium
- **Type**: Performance
- **Steps**:
  1. Log in with valid credentials
  2. Measure homepage load time from redirect to full page render
- **Expected Result**: Homepage loads in < 3 seconds, no performance lag
- **Actual Result**: [To be filled during test execution]
- **Status**: [Pass/Fail]
- **Notes**: [Use browser developer tools to measure load time]

---

## Test Summary Table

| TC ID | Title | Type | Priority | Status | Notes |
|-------|-------|------|----------|--------|-------|
| TC001 | Valid Login | Functional | High | [Pass/Fail] | |
| TC002 | Invalid Email Login | Negative | High | [Pass/Fail] | |
| TC003 | Wrong Password Login | Negative | High | [Pass/Fail] | |
| TC004 | Valid Registration | Functional | High | [Pass/Fail] | |
| TC005 | Duplicate Email Registration | Negative | High | [Pass/Fail] | |
| TC006 | View Restaurants | Functional | High | [Pass/Fail] | |
| TC007 | Search Restaurant | Functional | High | [Pass/Fail] | |
| TC008 | View Menu | Functional | High | [Pass/Fail] | |
| TC009 | Add to Cart | Functional | High | [Pass/Fail] | |
| TC010 | Increase Quantity | Functional | High | [Pass/Fail] | |
| TC011 | Decrease Quantity | Functional | High | [Pass/Fail] | |
| TC012 | Remove Item | Functional | High | [Pass/Fail] | |
| TC013 | Clear Cart | Functional | Medium | [Pass/Fail] | |
| TC014 | COD Order | Functional | High | [Pass/Fail] | |
| TC015 | Stripe Payment | Functional | High | [Pass/Fail] | |
| TC016 | Order Calculation | Functional | High | [Pass/Fail] | |
| TC017 | Order Confirmation | Functional | High | [Pass/Fail] | |
| TC018 | Track Order | Functional | High | [Pass/Fail] | |
| TC019 | View Order History | Functional | Medium | [Pass/Fail] | |
| TC020 | User Logout | Functional | High | [Pass/Fail] | |
| TC021 | Admin Login | Functional | High | [Pass/Fail] | |
| TC022 | Admin Add Item | Functional | High | [Pass/Fail] | |
| TC023 | Admin Edit Item | Functional | High | [Pass/Fail] | |
| TC024 | Admin Delete Item | Functional | High | [Pass/Fail] | |
| TC025 | Admin View Orders | Functional | High | [Pass/Fail] | |
| TC026 | Admin Update Status | Functional | High | [Pass/Fail] | |
| TC027 | Admin View Users | Functional | Medium | [Pass/Fail] | |
| TC028 | Empty Cart Validation | Negative | High | [Pass/Fail] | |
| TC029 | Blank Login Fields | Negative | Medium | [Pass/Fail] | |
| TC030 | Page Load Time | Performance | Medium | [Pass/Fail] | |

---
**Test Cases Version**: 1.0  
**Total Test Cases**: 30  
**Created Date**: January 2025  
**Last Updated**: January 2025
