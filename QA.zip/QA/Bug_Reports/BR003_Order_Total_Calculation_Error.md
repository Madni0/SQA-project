# Bug Report: BR003

## General Information
- **Bug ID**: BR003
- **Title**: Order Total Calculation Shows Incorrect Amount with Multiple Items
- **Date Reported**: January 18, 2025
- **Reporter**: QA Team
- **Status**: Open
- **Severity**: Critical
- **Priority**: P1 (Urgent)
- **Component**: Order Management / Checkout Module
- **Assigned To**: Backend Development Team

## Description
When placing an order with multiple items of different prices, the order total calculation is incorrect. The system appears to be adding only the first item's price multiple times instead of calculating the sum of all items' actual prices.

## Steps to Reproduce
1. Log in with valid credentials
2. Navigate to a restaurant menu
3. Add items to cart:
   - Item 1: Biryani (Rs. 500) - Quantity: 2 = Rs. 1000
   - Item 2: Karahi (Rs. 800) - Quantity: 1 = Rs. 800
4. Select delivery type: Standard (Rs. 50)
5. Navigate to checkout and review total
6. Expected: Subtotal Rs. 1800 + Delivery Rs. 50 = Rs. 1850
7. Observe the displayed total

## Expected Result
- **Subtotal**: Rs. 1800 (500×2 + 800×1)
- **Delivery Fee**: Rs. 50
- **Total**: Rs. 1850

## Actual Result
- **Subtotal**: Rs. 1500 (incorrect - 500×3)
- **Delivery Fee**: Rs. 50
- **Total**: Rs. 1550 (incorrect)

## Environment Details
- **Browser**: Google Chrome v120.0
- **OS**: Windows 11
- **Application URL**: http://localhost:3000
- **API Endpoint**: POST /api/orders
- **Database**: MongoDB

## Root Cause Investigation Needed
- Verify calculation logic in backend order service
- Check if item loop is correctly summing prices
- Investigate if quantity multiplier is properly applied per item
- Review database query joining orders with items

## Impact
- **Users**: May be overcharged or undercharged depending on item prices
- **Business**: Revenue discrepancy, customer disputes
- **Trust**: Users lose confidence in pricing accuracy

## Workaround
None - customers must either accept the incorrect total or cancel the order.

## Severity Justification
- Directly impacts payment and financial transactions
- Causes financial loss/gain discrepancy
- Violates trust and accuracy expectations
- Multiple payment methods affected

## Screenshots
[Screenshot 1: Cart items with individual prices]
[Screenshot 2: Checkout page showing incorrect total]
[Screenshot 3: Order confirmation showing wrong amount]

## Related Test Cases
- TC016: Verify Order Calculation with Delivery Fee
- TC014: Place Order with Cash on Delivery

## Recommendations
1. Review order calculation algorithm in backend
2. Add unit tests for order total calculation
3. Implement price verification before payment
4. Add detailed logging of calculation steps
5. Create test data with various item combinations
6. Add validation to ensure total = (sum of items) + delivery fee

## Additional Notes
This is a critical issue affecting financial integrity of the application. Immediate testing and fix required before user-facing release.

---
**Bug Report Version**: 1.0  
**Last Updated**: January 18, 2025
