# Bug Report: BR007

## General Information
- **Bug ID**: BR007
- **Title**: Stripe Payment Session Creation Fails - 500 Error
- **Date Reported**: January 18, 2025
- **Reporter**: QA Team
- **Status**: Open
- **Severity**: Critical
- **Priority**: P1 (Urgent)
- **Component**: Payment Gateway Integration / Checkout Module
- **Assigned To**: Backend Development Team

## Description
When customers attempt to pay for their order using Stripe (credit card payment), the system fails to create a Stripe checkout session and returns a 500 Internal Server Error. This prevents customers from completing orders using online payment, forcing them to use only Cash on Delivery method.

## Steps to Reproduce
1. Log in as customer (test@example.com / password123)
2. Add multiple items to cart (total > Rs. 500)
3. Navigate to checkout
4. Select delivery address and type
5. Select payment method: \"Credit Card\" or \"Stripe\"
6. Click \"Pay Now\" or \"Proceed to Payment\" button
7. Observe the response

## Expected Result
- HTTP Status: 200 OK
- Stripe checkout session created successfully
- Response contains Stripe session URL
- User redirected to Stripe payment form or modal
- Stripe payment page loads with order details
- Customer can enter payment information securely

## Actual Result
- HTTP Status: 500 Internal Server Error
- Error message: \"Failed to create payment session\"
- Stripe checkout modal/page does not appear
- User remains on checkout page with error
- Order is not created
- Payment cannot be processed

## Environment Details
- **Browser**: Chrome v120.0
- **OS**: Windows 11
- **Application URL**: http://localhost:3000
- **API Endpoint**: POST /api/stripe/checkout-session
- **Stripe Environment**: Test/Development Keys
- **Node.js Version**: 18.x

## Server Error Log
```
Error: Stripe API Error
Status: 400 Bad Request
Message: Invalid request: missing required param: customer
at stripe.checkout.sessions.create()
Stack: /src/app/api/stripe/checkout-session/route.ts:42
```

## Root Cause Analysis
- Stripe API keys may not be properly configured in environment
- Missing required fields in Stripe session request (customer_email, line_items)
- Stripe API credentials not set or expired
- CORS issues with Stripe API calls
- Line items array may be incorrectly formatted

## Business Impact
- **Revenue Loss**: Customers cannot pay online
- **User Experience**: Customers forced to use COD payment method
- **Trust**: Payment failure damages customer confidence
- **Abandoned Carts**: Customers may abandon orders due to payment issues

## Severity Justification
- Blocks critical payment functionality
- Direct revenue impact
- Core business feature (payment processing)
- Affects paying customers attempting to checkout

## Screenshots
[Screenshot 1: Checkout page with payment methods]
[Screenshot 2: Error message \"Failed to create payment session\"]
[Screenshot 3: Browser console showing 500 error response]
[Screenshot 4: Network tab showing failed API request]

## Related Test Cases
- TC015: Place Order with Stripe Payment
- API Test: POST /api/stripe/checkout-session

## Recommendations
1. Verify Stripe API keys are correctly set in .env.local
2. Check if test keys vs live keys are properly configured
3. Validate request body sent to Stripe API
4. Ensure all required fields are included in session creation
5. Add proper error handling and logging
6. Test with Stripe test cards in development
7. Implement retry logic for failed session creation
8. Add customer email to session creation request
9. Validate line items array structure
10. Test webhook configuration for payment confirmations

## Environment Variable Checklist
- [ ] STRIPE_PUBLIC_KEY is set
- [ ] STRIPE_SECRET_KEY is set
- [ ] STRIPE_WEBHOOK_SECRET is set (if using webhooks)
- [ ] Keys are for test environment (start with pk_test_, sk_test_)
- [ ] Keys are not expired
- [ ] Keys have correct permissions

## Sample Request Expected
```javascript
const session = await stripe.checkout.sessions.create({
  customer_email: 'test@example.com',
  payment_method_types: ['card'],
  line_items: [
    {
      price_data: {
        currency: 'pkr',
        product_data: { name: 'Biryani' },
        unit_amount: 50000, // 500 in lowest currency unit
      },
      quantity: 2,
    },
  ],
  mode: 'payment',
  success_url: 'http://localhost:3000/order-success',
  cancel_url: 'http://localhost:3000/cart',
});
```

---
**Bug Report Version**: 1.0  
**Last Updated**: January 18, 2025
