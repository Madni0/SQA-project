import { test, expect } from '@playwright/test';

test.describe('User Authentication Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000');
  });

  test('TC001: User Login with Valid Credentials', async ({ page }) => {
    // Navigate to login page
    await page.click('text=Login');
    
    // Fill login form
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    
    // Submit login form
    await page.click('button[type="submit"]');
    
    // Verify successful login - check for navigation or element indicating logged-in state
    await expect(page).toHaveURL(/.*dashboard|.*home/);
    
    // Verify user profile is accessible
    const userProfile = page.locator('text=Profile');
    await expect(userProfile).toBeVisible({ timeout: 5000 });
  });

  test('TC002: User Login with Invalid Email', async ({ page }) => {
    await page.click('text=Login');
    
    await page.fill('input[name="email"]', 'nonexistent@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    
    // Verify error message is displayed
    const errorMessage = page.locator('[class*="error"], [class*="alert"]');
    await expect(errorMessage).toContainText(/user not found|invalid|credentials/i);
  });

  test('TC003: User Login with Wrong Password', async ({ page }) => {
    await page.click('text=Login');
    
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'wrongpassword');
    await page.click('button[type="submit"]');
    
    // Verify error message
    const errorMessage = page.locator('[class*="error"], [class*="alert"]');
    await expect(errorMessage).toContainText(/incorrect|invalid|credentials/i);
  });

  test('TC004: User Registration with Valid Data', async ({ page }) => {
    // Navigate to registration
    await page.click('text=Register');
    
    // Fill registration form with unique email
    const timestamp = Date.now();
    const newEmail = `newuser${timestamp}@example.com`;
    
    await page.fill('input[name="name"]', 'John Doe');
    await page.fill('input[name="phone"]', '03001234567');
    await page.fill('input[name="email"]', newEmail);
    await page.fill('input[name="password"]', 'SecurePass123');
    await page.fill('input[name="confirmPassword"]', 'SecurePass123');
    
    // Submit registration
    await page.click('button[type="submit"]');
    
    // Verify successful registration
    await expect(page).toHaveURL(/.*dashboard|.*home|.*success/);
    
    // Verify welcome message or confirmation
    const successMessage = page.locator('text=/welcome|registered|successfully/i');
    await expect(successMessage).toBeVisible({ timeout: 5000 });
  });

  test('TC005: User Registration with Existing Email', async ({ page }) => {
    await page.click('text=Register');
    
    // Try to register with already existing email
    await page.fill('input[name="name"]', 'Another User');
    await page.fill('input[name="phone"]', '03009876543');
    await page.fill('input[name="email"]', 'test@example.com'); // Already exists
    await page.fill('input[name="password"]', 'Password123');
    await page.fill('input[name="confirmPassword"]', 'Password123');
    
    await page.click('button[type="submit"]');
    
    // Verify error message about existing email
    const errorMessage = page.locator('[class*="error"], [class*="alert"]');
    await expect(errorMessage).toContainText(/already exists|already registered/i);
  });

  test('TC020: User Logout', async ({ page }) => {
    // First login
    await page.click('text=Login');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button[type="submit"]');
    
    // Wait for successful login
    await page.waitForURL(/.*dashboard|.*home/);
    
    // Find and click logout button
    await page.click('[class*="menu"], [class*="profile"]');
    await page.click('text=Logout');
    
    // Verify redirect to login page
    await expect(page).toHaveURL(/.*login/);
    
    // Verify profile is no longer visible
    const userProfile = page.locator('text=Profile');
    await expect(userProfile).not.toBeVisible({ timeout: 2000 });
  });

  test('TC029: Login with Blank Email and Password', async ({ page }) => {
    await page.click('text=Login');
    
    // Try to submit without filling fields
    const submitButton = page.locator('button[type="submit"]');
    await submitButton.click();
    
    // Check for validation error
    const emailInput = page.locator('input[name="email"]');
    const validationMessage = await emailInput.evaluate((el: HTMLInputElement) => el.validationMessage);
    
    expect(validationMessage).toBeTruthy();
  });
});
