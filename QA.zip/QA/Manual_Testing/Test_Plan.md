# Test Plan for LayyahEats - Online Food Delivery Application

## 1. Introduction
- **Project Name**: LayyahEats
- **Project Description**: A premium web-based food delivery application designed to serve residents of Layyah. Users can browse restaurants, view menus, manage shopping carts, place orders, and track deliveries. Admin users can manage menus, restaurants, orders, and user data.
- **Test Objective**: Ensure all functional features work correctly, identify defects, and validate the application's quality standards across all user types (Customer, Admin).
- **Scope**: 
  - In Scope: User authentication (login, register, logout), restaurant browsing, menu management, shopping cart operations, order placement with multiple payment methods, order tracking, and admin dashboard operations.
  - Out of Scope: Third-party integrations (Stripe payment processing details, Twilio SMS integration) unless directly impacting application functionality.
- **Out of Scope**: External payment gateway processing, SMS delivery verification.

## 2. Test Strategy
- **Testing Types**: 
  - Functional Testing: Verify all features work as expected.
  - Negative Testing: Test error handling and edge cases.
  - UI/UX Testing: Validate user interface layout and usability.
  - Compatibility Testing: Test on Chrome and Firefox browsers.
  - API Testing: Validate all REST API endpoints.
  - Automation Testing: Automate critical user workflows using Playwright.

- **Test Environment**: 
  - Local development environment (http://localhost:3000)
  - Browser: Google Chrome (Primary), Firefox (Secondary)
  - Database: MongoDB (Local instance)
  - API Tools: Postman for API testing
  - Automation Tool: Playwright

- **Test Roles**: 
  - Tester/QA Engineer: Executes test cases and documents results.
  - Developer: Receives defect reports and implements fixes.
  - Stakeholder: Reviews test summary reports and quality metrics.

- **Risks**: 
  - MongoDB connection failures may impact data retrieval.
  - Payment gateway failures may prevent order placement testing.
  - Environment-specific issues not identified in production.
  - Data consistency issues across distributed transactions.

## 3. Test Schedule
| Phase | Duration | Activities |
|-------|----------|-----------|
| Planning & Preparation | 2 days | Test plan creation, test case design, environment setup |
| Manual Testing | 3 days | Test case execution, evidence capture, result documentation |
| Automation Testing | 2 days | Playwright script development, execution, report generation |
| API Testing | 2 days | Postman collection creation, test execution, validation |
| Defect Reporting | 2 days | Bug identification, documentation, severity assignment |
| Reporting & Documentation | 2 days | Summary reports, traceability matrix, presentation slides |
| **Total** | **13 days** | |

## 4. Deliverables
| Deliverable | Format | Location |
|---|---|---|
| Test Plan | Markdown | QA/Manual_Testing/Test_Plan.md |
| Test Cases | Markdown | QA/Manual_Testing/Test_Cases.md |
| Manual Test Execution Evidence | Screenshots | QA/Manual_Testing/screenshots/ |
| Playwright Automation Scripts | TypeScript | QA/Automation/*.spec.ts |
| Playwright Test Reports | HTML | QA/Automation/reports/ |
| Postman API Collection | JSON | QA/API_Testing/Postman_Collection.json |
| Bug Reports | Markdown | QA/Bug_Reports/Bug_*.md |
| Test Summary Report | Markdown | QA/Reports/Test_Summary_Report.md |
| Defect Summary Report | Markdown | QA/Reports/Defect_Summary_Report.md |
| Traceability Matrix | Markdown | QA/Reports/Traceability_Matrix.md |
| Project Report | PDF/Markdown | QA/Reports/Project_Report.md |

## 5. Test Metrics & Acceptance Criteria
- **Test Case Execution**: Target 95%+ test case pass rate.
- **Defect Detection**: Identify and document all critical and high-priority defects.
- **Code Coverage**: Minimum 80% feature coverage across all modules.
- **Automation**: Achieve 8-10 automated critical test cases.
- **API Coverage**: Test 6-8 key REST API endpoints.

## 6. Test Environment Setup
1. **Prerequisites**:
   - Node.js 16+ installed
   - MongoDB running locally
   - Postman installed
   - Playwright browsers installed
   - Chrome/Firefox browsers updated

2. **Setup Steps**:
   ```bash
   npm install
   npm install -D @playwright/test
   npx playwright install
   npm run dev  # Start the application on http://localhost:3000
   ```

3. **Test Data**:
   - Valid user credentials: test@example.com / password123
   - Test restaurant data with menu items pre-populated in MongoDB
   - Multiple payment method test data

## 7. Defect Management
- **Defect Severity Levels**:
  - **Critical**: Application crash, complete feature unavailability.
  - **High**: Major functionality broken, workaround difficult.
  - **Medium**: Feature partially broken, workaround available.
  - **Low**: Minor UI issues, cosmetic defects.

- **Defect Priority Levels**:
  - **P1 (Urgent)**: Must fix before release.
  - **P2 (High)**: Should fix in current release.
  - **P3 (Medium)**: Can fix in next release.
  - **P4 (Low)**: Nice to have, can defer.

## 8. Test Execution & Reporting
- Execute test cases in sequence as per priority.
- Document all results in test case documents.
- Capture screenshots for evidence.
- Generate automation test reports automatically.
- Create summary reports with metrics and trends.

## 9. Approval & Sign-off
- Test plan approved by QA Lead.
- Final test report reviewed by Project Manager.
- All critical defects resolved before UAT sign-off.

---
**Test Plan Version**: 1.0  
**Created Date**: January 2025  
**Last Updated**: January 2025
