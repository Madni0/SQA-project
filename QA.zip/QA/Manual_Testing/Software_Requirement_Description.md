# Software Requirement Description - LayyahEats

## 1. Project Overview
**LayyahEats** is a premium food delivery web application designed to serve the residents of Layyah. It allows users to browse various restaurants, view their menus, add items to a cart, and place orders using Cash on Delivery or Stripe payment gateway.

## 2. Target Audience
- Residents of Layyah looking for food delivery.
- Restaurant owners/managers (Admin) who need to manage their menus and orders.

## 3. Key Features

### 3.1 User Authentication
- **Login**: Existing users can log in using their email and password.
- **Registration**: New users can create an account by providing their name, phone number, email, and password.
- **Logout**: Users can securely sign out of their accounts.

### 3.2 Restaurant & Menu Browsing
- **Homepage**: Displays featured restaurants and food categories.
- **Search**: Users can search for specific food items or restaurants.
- **Menu Listing**: Users can view all available menu items, filtered by restaurant or category.

### 3.3 Shopping Cart Management
- **Add to Cart**: Users can add items from the menu to their shopping cart.
- **Update Quantity**: Users can increase or decrease the quantity of items in their cart.
- **Remove Item**: Users can remove specific items or clear the entire cart.

### 3.4 Ordering & Payment
- **Order Placement**: Users can place orders for items in their cart.
- **Cash on Delivery**: A standard payment option for all orders.
- **Stripe Integration**: Secure online payment processing.
- **Delivery Fee**: Dynamic delivery fees (Free, Standard, Express).

### 3.5 Order Tracking
- **Real-time Status**: Users can track the status of their orders (Pending, Preparing, Out for Delivery, Delivered).

### 3.6 Admin Dashboard
- **Menu Management**: Admins can add, edit, or remove menu items.
- **Restaurant Management**: Admins can manage restaurant listings.
- **Order Management**: Admins can view and update order statuses.
- **User Management**: Admins can view and manage registered users.

## 4. Technical Stack
- **Frontend**: Next.js 15+, Tailwind CSS, React 19.
- **Backend**: Next.js API Routes.
- **Database**: MongoDB.
- **Integrations**: Stripe (Payments), Nodemailer (Emails), Twilio (SMS Notifications).
