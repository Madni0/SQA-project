# Bug Report: BR005

## General Information
- **Bug ID**: BR005
- **Title**: Restaurant Menu Cards Overflow Screen on Mobile View
- **Date Reported**: January 18, 2025
- **Reporter**: QA Team
- **Status**: Open
- **Severity**: High
- **Priority**: P2 (High)
- **Component**: UI/UX - Responsive Design
- **Assigned To**: Frontend Development Team

## Description
On mobile devices (width ≤ 768px), the restaurant menu cards exceed the screen boundaries and are not properly responsive. Text overflows, buttons are cut off, and navigation becomes difficult on smaller screens.

## Steps to Reproduce
1. Open application in mobile browser or use Chrome DevTools responsive mode
2. Set viewport to iPhone 12 (390 × 844 pixels)
3. Navigate to homepage
4. Scroll to restaurant listings section
5. Observe card layout and content

## Expected Result
- Restaurant cards adapt to mobile screen width
- Cards display in single column on mobile
- Restaurant name, image, and rating are fully visible
- "View Menu" button is accessible and clickable
- Text does not overflow boundaries
- Padding and margins are appropriate for mobile

## Actual Result
- Cards span beyond screen width
- Horizontal scrolling required to see full card
- Restaurant name text overflows card boundary
- "View Menu" button is partially cut off
- Images are not properly scaled
- Content is difficult to interact with on mobile

## Environment Details
- **Devices Tested**:
  - iPhone 12 (390 × 844)
  - Samsung Galaxy S21 (360 × 800)
  - Google Pixel 5 (393 × 851)
- **Browsers**: Chrome Mobile, Safari Mobile
- **Application URL**: http://localhost:3000
- **Breakpoint**: Not responsive below 768px

## CSS Issues Identified
- Missing or incorrect media queries
- Fixed widths instead of relative units
- Flex/Grid not properly configured for small screens
- Padding/margin values too large for mobile

## Visual Comparison
| Element | Desktop (1920px) | Mobile (390px) |
|---------|-----------------|----------------|
| Card Width | 300px (4 columns) | 300px (OVERFLOW!) |
| Font Size | 16px | 16px (too large) |
| Padding | 20px | 20px (too much) |
| Button Width | auto | CUT OFF |

## User Impact
- Mobile users cannot properly browse restaurants
- Order placement difficult on mobile
- Reduced conversion rate on mobile platform
- Poor user experience

## Severity Justification
- Impacts significant user base (mobile users)
- Blocks primary functionality on mobile
- Affects user experience and conversion
- Design/UI issue affecting multiple pages

## Screenshots
[Screenshot 1: Desktop view - properly formatted cards]
[Screenshot 2: Mobile view - cards overflowing]
[Screenshot 3: Mobile view zoomed in showing text overflow]

## Related Test Cases
- UI/UX Testing for responsive design
- Mobile compatibility testing

## Recommendations
1. Add mobile-first CSS media queries
2. Use CSS Grid or Flexbox with proper responsive values
3. Change fixed widths to percentage/viewport units
4. Test on multiple mobile devices and orientations
5. Implement proper breakpoints (320px, 480px, 768px, 1024px)
6. Use CSS preprocessor (SCSS) for better organization
7. Implement automated visual regression testing
8. Test with real devices and not just DevTools

## Code Example Needed
```css
/* Current (Broken) */
.restaurant-card {
  width: 300px;
  padding: 20px;
}

/* Should be */
.restaurant-card {
  width: 100%;
  max-width: 300px;
  padding: 16px;
}

@media (max-width: 768px) {
  .restaurant-card {
    max-width: 100%;
    padding: 12px;
  }
}
```

---
**Bug Report Version**: 1.0  
**Last Updated**: January 18, 2025
